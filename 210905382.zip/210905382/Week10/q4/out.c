#include <stdio.h>
int main()
{
    int number;
    write("enter a number:");
    read("%d", &number);
    write("cube of number is:%d ", number * number * number);
    return 0;
}