#include<stdio.h>
#include<stdlib.h>

int main(){
    FILE* fptr1;
    int charCount = 0;
    int lineCount = 0;
    char filename[20], c;
    printf("Enter the file name:\n");
    scanf("%s", filename);
    fptr1 = fopen(filename, "r" );
    if(fptr1 == NULL){
        printf("File not found:\n");
        exit(0);
    }
    c = fgetc(fptr1);
    while(c != EOF){
        charCount++;
        if(c == '\n'){
            lineCount++;
        }
        c = fgetc(fptr1);
    }
    printf("Number of Charachters: %d\n", charCount);
    printf("Number of Lines: %d\n", lineCount);
    fclose(fptr1);
    return 0;
}