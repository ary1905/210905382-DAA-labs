#include<stdio.h>
#include<stdlib.h>

int main()
{
    FILE *fptr1, *fptr2;
    char filename[20], c;
    printf("Enter file name for reading:\n");
    scanf("%s", filename);
    fptr1 = fopen(filename, "r");
    printf("Enter file name for writing:\n");
    scanf("%s", filename);
    fptr2 = fopen(filename, "w");
    fseek(fptr1, 0, SEEK_END);
    int iter = ftell(fptr1);
    int i = 0;
    while(i != iter){
        i++;
        c = fgetc(fptr1); 
        fputc(c, fptr2);
        fseek(fptr1, -i, SEEK_END);
    }
    printf("Done\n");
    printf("Size of the file: %d\n", iter);
    fclose(fptr1);
    fclose(fptr2);
    return 0;
}
