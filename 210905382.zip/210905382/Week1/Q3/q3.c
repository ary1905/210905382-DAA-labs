#include<stdio.h>
#include<stdlib.h>

int main(int argc, char const *argv[])
{
    FILE *fptr1, *fptr2, *fptr3;
    char filename[20], c1, c2;
    printf("Enter file name for reading First file:\n");
    scanf("%s", filename);
    fptr1 = fopen(filename, "r");
    if(fptr1 == NULL){
        printf("File not found:\n");
        exit(0);
    }
    printf("Enter file name for reading Second file:\n");
    scanf("%s", filename);
    fptr2 = fopen(filename, "r");
    if(fptr2 == NULL){
        printf("File not found:\n");
        exit(0);
    }
    printf("Enter file name for write file:\n");
    scanf("%s", filename);
    fptr3 = fopen(filename, "w");
    if(fptr3 == NULL){
        printf("File not found:\n");
        exit(0);
    }
    c1 = fgetc(fptr1);
    c2 = fgetc(fptr2);
    while(c1 != EOF || c2 != EOF){
        while(c1 != '\n'){
            fputc(c1, fptr3);
            c1 = fgetc(fptr1);
        }
        while(c2 != '\n'){
            fputc(c2, fptr3);
            c2 = fgetc(fptr2);
        }
    }
    if(c1 == EOF){
        while(c2 != EOF){
            fputc(c2, fptr3);
            c2 = fgetc(fptr2);
        }
    }
    if(c2 == EOF){
        while(c1 != EOF){
            fputc(c1, fptr3);
            c1 = fgetc(fptr1);
        }
    }
    fclose(fptr1);
    fclose(fptr2);
    fclose(fptr3);
    return 0;
}
