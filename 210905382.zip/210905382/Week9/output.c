int main()
{
	float axe, box;
	double cat;
	int firstInt, secondInt, x, third[5];
	axe = box;
	while (firstInt <= secondInt)
	{
		if (firstInt)
		{
			for (x = 0; x <= 10; x = x + 1)
			{
				if (x)
				{
					secondInt = firstInt;
				}
				firstInt = firstInt + 1;
			}
		}
	}
	return 0;
}
