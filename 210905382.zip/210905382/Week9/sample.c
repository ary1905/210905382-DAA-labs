int main()
{
    int n;
    if (n < 10)
    {
        return 10;
    }
}