
int sum(int a, int b){
    return 0;
}

int main()
{
    int a, b, sum;
    a = 10;
    b = 11;
    sum = a + b;
    printf("hello");
    return 0;
}