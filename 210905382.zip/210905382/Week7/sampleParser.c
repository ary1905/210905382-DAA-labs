main(){
    int a, b;
    char c;
    a = 10;
}