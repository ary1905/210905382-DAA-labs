#include <stdio.h>
#include <stdlib.h>

int main()
{
	float firstFlo, secondFlo;
	int firstInt, secondInt, firstArr[10];
	char firstChar;
	double firstDo;
	firstInt = 1;
	secondInt = firstInt + 1; 
	firstFlo = firstChar;
	firstInt = secondInt * 5;
	return 0;
}
