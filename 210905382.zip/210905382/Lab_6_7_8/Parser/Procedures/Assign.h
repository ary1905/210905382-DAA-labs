#ifndef __ASSIGN_H__
#define __ASSIGN_H__
void AssignStat()
{
	get();
	if (search_symbol(tkn->lexeme) != -1)
	{
		get();
		if (strcmp(tkn->lexeme, "=") == 0)
		{
			get();
			prev_flag = true;
			if (search_first(EXPN, tkn->lexeme, tkn->type) == 1)
				Expn();
			else
				failure("Assignment error, Invalid Identifier or number at position");
		}
		else
		{
			failure("Assignment error, = sign not found! at position");
		}
	}
	else
	{
		failure("Assignment error, Invalid Identifier! at position");
	}
}

#endif