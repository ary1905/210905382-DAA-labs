#include <stdio.h>
#include <stdlib.h>

int main()
{
	float axe, box;
	double cat;
	int firstInt, secondInt, x, third[5];
	while (firstInt == secondInt)
	{
		if (firstInt == secondInt)
		{
			for (x = 0; x <= 10; x = x + 1)
			{
				if (x == 4)
				{
					secondInt = firstInt;
				}
				firstInt = firstInt + 1;
			}
		}
	}
	return 0;
}
