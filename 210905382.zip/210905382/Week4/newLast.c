#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "modifiy.h"

char type[10];
int srNo = 1;

char dataType[6][10] = {"int", "double", "long", "short", "float", "char"};

char keywords[30][10] = {"auto", "struct",
                         "break", "else", "switch", "case", "enum", "register",
                         "typedef", "extern", "return", "union", "const",
                         "unsigned", "continue", "for", "signed", "void",
                         "default", "goto", "sizeof", "voltile", "do", "if", "static",
                         "while", "printf", "scanf"};

struct token
{
    char token_name[10];
    unsigned int row, col;
} a;

struct node
{
    int serialNum;
    char *lexemeName;
    char *tokenType;
    char *dataType;
    char *returnType;
    int argNum;
    struct node *next;
};

struct node *symbolTable = NULL;

void addToSymbolTable(char *lexemeName, char *tokenType, char *dataType, char *returnType, int argNum)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->serialNum = srNo++;
    newNode->lexemeName = strdup(lexemeName);
    newNode->tokenType = strdup(tokenType);
    newNode->dataType = strdup(dataType);
    newNode->returnType = strdup(returnType);
    newNode->argNum = argNum;
    newNode->next = symbolTable;
    symbolTable = newNode;
}

void printSymbolTable()
{
    struct node *current = symbolTable;
    printf("\n\nSymbol Table:\n");
    printf("Serial No\tLexeme Name\tToken Type\tData Type\tReturn Type\tArg Num\n");
    while (current != NULL)
    {
        printf("%d\t\t%s\t\t%s\t\t%s\t\t%s\t\t%d\n", current->serialNum, current->lexemeName, current->tokenType, current->dataType, current->returnType, current->argNum);
        current = current->next;
    }
}

int search(char buf[10])
{
    struct node *head = symbolTable;
    while (head != NULL)
    {
        if (strcmp(buf, head->lexemeName) == 0)
        {
            return 1;
        }
        head = head->next;
    }
    return 0;
}

int compare(char buffer[])
{
    for (int i = 0; i < 32; i++)
    {
        if (strcmp(buffer, keywords[i]) == 0)
        {
            return 1;
        }
    }
    return 0;
}

int dataCompare(char buffer[])
{
    for (int i = 0; i < 6; i++)
    {
        if (strcmp(buffer, dataType[i]) == 0)
        {
            return 1;
        }
    }
    return 0;
}

void relArithLogical()
{
    FILE *fp;
    fp = fopen("digit1.c", "r");
    char c, buf[30];
    c = fgetc(fp);
    int colNumber = 0;
    int rowNumber = 1;
    while (c != EOF)
    {
        if (c == '\n')
        {
            rowNumber++;
            colNumber = 0;
            c = fgetc(fp);
            continue;
        }
        colNumber++;
        int i = 0;
        buf[0] = '\0';
        if (c == '=')
        {
            buf[i++] = c;
            c = fgetc(fp);

            if (c == '=')
            {
                colNumber++;
                buf[i++] = c;
                buf[i] = '\0';
                strcpy(a.token_name, buf);
                a.row = rowNumber;
                a.col = colNumber;
                printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
            }
            else
            {
                buf[i] = '\0';
                strcpy(a.token_name, buf);
                a.row = rowNumber;
                a.col = colNumber;
                printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
            }
        }
        else
        {
            if (c == '<' || c == '>' || c == '!')
            {
                buf[i++] = c;
                c = fgetc(fp);
                if (c == '=')
                {
                    buf[i++] = c;
                    colNumber++;
                    buf[i] = '\0';
                    strcpy(a.token_name, buf);
                    a.row = rowNumber;
                    a.col = colNumber;
                    printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
                }
                buf[i] = '\0';
                strcpy(a.token_name, buf);
                a.row = rowNumber;
                a.col = colNumber;
                printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
            }
            else if (c == '&')
            {
                buf[i++] = c;
                c = fgetc(fp);
                if (c == '&')
                {
                    buf[i++] = c;
                    colNumber++;
                    buf[i] = '\0';
                    strcpy(a.token_name, buf);
                    a.row = rowNumber;
                    a.col = colNumber;
                    printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
                }
            }
            else if (c == '|')
            {
                buf[i++] = c;
                c = fgetc(fp);
                if (c == '|')
                {
                    buf[i++] = c;
                    colNumber++;
                    buf[i] = '\0';
                    strcpy(a.token_name, buf);
                    a.row = rowNumber;
                    a.col = colNumber;
                    printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
                }
                else
                {
                    buf[i] = '\0';
                    strcpy(a.token_name, buf);
                    a.row = rowNumber;
                    a.col = colNumber;
                    printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
                }
            }
            else if (c == '+' || c == '-' || c == '/' || c == '*' || c == '%')
            {
                buf[i++] = c;
                c = fgetc(fp);
                if (c == '=')
                {
                    buf[i++] = c;
                    colNumber++;
                    buf[i] = '\0';
                    strcpy(a.token_name, buf);
                    a.row = rowNumber;
                    a.col = colNumber;
                    printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
                }
                else
                {
                    switch (buf[i - 1])
                    {
                    case '+':
                        if (c == '+')
                            buf[i++] = c;
                        break;
                    case '-':
                        if (c == '-')
                            buf[i++] = c;
                        break;
                    }
                    buf[i] = '\0';
                    strcpy(a.token_name, buf);
                    a.row = rowNumber;
                    a.col = colNumber;
                    printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
                }
            }
        }
        c = fgetc(fp);
    }
    fclose(fp);
}

void specKeyNumStringIde()
{
    FILE *fp;
    fp = fopen("digit1.c", "r");
    char c, buf[500];
    c = fgetc(fp);
    int colNumber = 0;
    int rowNumber = 1;
    while (c != EOF)
    {
        if (c == '\n')
        {
            rowNumber++;
            colNumber = 0;
            c = fgetc(fp);
            continue;
        }
        colNumber++;
        int i = 0;
        buf[0] = '\0';
        if (c == '{' || c == '}' || c == '(' || c == ')' || c == '[' || c == ']' || c == ';' || c == ',')
        {
            buf[i++] = c;
            buf[i] = '\0';
            strcpy(a.token_name, buf);
            a.row = rowNumber;
            a.col = colNumber;
            printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
        }
        else if (isdigit(c))
        {
            while (isdigit(c))
            {
                buf[i++] = c;
                c = fgetc(fp);
            }
            colNumber++;
            buf[i] = '\0';
            strcpy(a.token_name, buf);
            a.row = rowNumber;
            a.col = colNumber;
            printf("\n <%s,%d,%d>", "num", a.row, a.col);
            i++;
            buf[i] = c;
            continue;
        }
        else if (c == '\"')
        {
            buf[i++] = c;
            c = fgetc(fp);
            while (c != '\"')
            {
                buf[i++] = c;
                c = fgetc(fp);
            }
            buf[i++] = c;
            colNumber++;
            buf[i] = '\0';
            strcpy(a.token_name, buf);
            a.row = rowNumber;
            a.col = colNumber;
            printf("\n <%s,%d,%d>", "String Literal", a.row, a.col);
        }
        else if (c == '\'')
        {
            buf[i++] = c;
            c = fgetc(fp);
            while (c != '\'')
            {
                buf[i++] = c;
                c = fgetc(fp);
            }
            buf[i++] = '\'';
            colNumber++;
            buf[i] = '\0';
            strcpy(a.token_name, buf);
            a.row = rowNumber;
            a.col = colNumber;
            printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
        }
        else if (isalpha(c) != 0)
        {
            buf[i++] = c;
            while (isalpha(c) != 0 || c == '_' || isdigit(c))
            {
                c = fgetc(fp);
                if (isalpha(c) != 0 || c == '_' || isdigit(c))
                {
                    buf[i++] = c;
                    colNumber++;
                }
            }
            buf[i] = '\0';

            if (compare(buf) == 1)
            {
                strcpy(a.token_name, buf);
                a.row = rowNumber;
                a.col = colNumber;
                printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
            }
            else if (dataCompare(buf) == 1)
            {
                strcpy(a.token_name, buf);
                a.row = rowNumber;
                a.col = colNumber;
                printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
                strcpy(type, a.token_name);
            }
            else if (strcmp("main", buf) == 0)
            {
                strcpy(a.token_name, buf);
                a.row = rowNumber;
                a.col = colNumber;
                printf("\n <%s,%d,%d>", "id", a.row, a.col);
                if (!search(a.token_name))
                {
                    addToSymbolTable(buf, "FUNCTION", "-", type, 0);
                }
            }
            else
            {
                int funcFlag = 0;
                int count = 0;
                int commaCount = 0;
                int spaceFlag = 1;
                char ch;
                while (isalpha(c) != 0 || c == '_' || isdigit(c))
                {
                    buf[i++] = c;
                    c = fgetc(fp);
                }

                if (c == '(')
                {
                    funcFlag = 1;
                    ch = fgetc(fp);
                    while (ch != ')')
                    {
                        count++;
                        if (isalpha(ch))
                        {
                            spaceFlag = 0;
                        }
                        if (ch == ',')
                        {
                            commaCount++;
                        }
                        ch = fgetc(fp);
                    }
                }
                if (spaceFlag)
                {
                    commaCount = -1;
                }
                fseek(fp, -count, SEEK_CUR);

                buf[i] = '\0';
                strcpy(a.token_name, buf);
                a.row = rowNumber;
                a.col = colNumber;
                printf("\n <%s,%d,%d>", "id", a.row, a.col);
                if (!search(a.token_name))
                {
                    if (funcFlag)
                    {
                        addToSymbolTable(buf, "FUNCTION", "-", type, commaCount + 1);
                    }
                    else
                    {
                        addToSymbolTable(buf, "VARIABLE", type, "-", 0);
                    }
                }
            }
            i++;
            buf[i++] = c;
            continue;
        }
        else if (c == '_')
        {
            while (isalpha(c) != 0 || c == '_' || isdigit(c))
            {
                buf[i++] = c;
                c = fgetc(fp);
            }
            buf[i] = '\0';
            strcpy(a.token_name, buf);
            a.row = rowNumber;
            a.col = colNumber;
            printf("\n <%s,%d,%d>", a.token_name, a.row, a.col);
            buf[++i] = c;
            continue;
        }
        c = fgetc(fp);
    }
    fclose(fp);
}

void getNextToken()
{
    printf("The tokens generated for special symbols, keywords, numerical constants, string literals and identifiers are: ");
    specKeyNumStringIde();
    printf("\n\nThe tokens generated for relational, arithmetic and logical operators are: ");
    relArithLogical();
}

int main()
{
    FILE *fp1, *fptr2;
    fp1 = fopen("digit.c", "r");
    if (fp1 == NULL)
    {
        printf("File does not exist");
        exit(0);
    }
    fptr2 = fopen("digit1.c", "w+");
    char ch = fgetc(fp1);
    int c = 0;
    while (ch != EOF)
    {
        if (ch == '"')
        {
            if (c == 1)
            {
                fputc(ch, fptr2);
                c = 0;
                ch = fgetc(fp1);
            }
            else
            {
                fputc(ch, fptr2);
                c = 1;
                ch = fgetc(fp1);
            }
        }
        if (ch == '#')
        {
            while (ch != '\n')
                ch = fgetc(fp1);
        }
        else
            fputc(ch, fptr2);
        ch = fgetc(fp1);
    }
    fclose(fptr2);
    getNextToken();
    printSymbolTable();
    fclose(fp1);
}
