#include<stdio.h>
#include<stdlib.h>
#include<string.h>

const char *directive[] = {"#include", "#define", "#if", "#endif"};

int isDir(const char *str)
{
    for(int i = 0; i < sizeof(directive)/sizeof(char *); i++)
    {
        int len = strlen(directive[i]);
 
        if(strncmp(str, directive[i], len) == 0)
        {
                return 1;
        }
    }
    return 0;
}

int main(int argc, char const *argv[])
{
    FILE *fa, *fb;
    char str[50];
    printf("Enter input file:\n");
    scanf("%s", str);
    fa = fopen(str, "r");
    if(fa == NULL){
        printf("File Not found\n");
        exit(0);
    }
    printf("Enter output file:\n");
    scanf("%s", str);
    fb = fopen(str, "w");

    char buffer[1000];

    while(fgets(buffer, 1000, fa) != NULL){
        if(!isDir(buffer)){
            fputs(buffer, fb);
        }
    }

    fclose(fa);
    fclose(fb);
    return 0;
}
