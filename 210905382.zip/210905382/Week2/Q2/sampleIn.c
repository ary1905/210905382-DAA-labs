#include<stdio.h>
#include<stdlib.h>
#define c 10

int main(int argc, char const *argv[])
{
    printf("Hello World");
    return 0;
}
