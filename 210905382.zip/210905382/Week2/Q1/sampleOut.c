#include<stdio.h>
 #include<stdlib.h>
//Header Files in C

int main(int argc, char const *argv[])
{
 //Program to Print Hello World.
 printf("Hello World");
 return 0;
}
