#include<stdio.h>
#include<stdlib.h>
#define c 10

int main(int argc, char const *argv[])
{
    #if (c == 10)
        printf("Hello World");
    #endif
    
    return 0;
}
