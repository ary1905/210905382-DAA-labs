#include<stdio.h>
#include<stdlib.h>

int main(int argc, char const *argv[])
{
    FILE *fa, *fb;
    char str[50];
    printf("Enter input file:\n");
    scanf("%s", str);
    fa = fopen(str, "r");
    if(fa == NULL){
        printf("File Not found\n");
        exit(0);
    }
    printf("Enter output file:\n");
    scanf("%s", str);
    fb = fopen(str, "w");

    int space_flag = 0;
    char ch;

    while (1)
    {
        ch = fgetc(fa);

        if(ch == EOF)
            break;

        if(!space_flag && (ch == ' ' || ch == '\t')){
            fputc(' ', fb);
            space_flag = 1;
        }

        else if (!(ch == ' ' || ch == '\t'))
        {
            fputc(ch, fb);
            space_flag = 0;
        }
    }
    fclose(fa);
    fclose(fb);
    return 0;
}
